const container = document.querySelector(".container");
const btn = document.querySelector(".form-wrapper-left button");

btn.addEventListener("click", () => {
  container.classList.toggle("switch");
});





function showAlert() {
    alert("We will be in touch with you shortly.");
}

document.addEventListener("DOMContentLoaded", function() {
    var button = document.getElementById("alertButton");
    button.addEventListener("click", showAlert);
});
